<?php
include("conexion.php");

if ($_FILES['image']['size']>2000000) {
	# code...
	print "<script>alert('Solo se pueden enviar imágenes de hasta 2MB.')</script>";
	print"<script>location.href=\"redactarNoticia.php\"</script>";
}

$dir="imagenesSubidas/";
$nombreImagen= $_FILES['image']['name'];

if (!move_uploaded_file($_FILES['image']['tmp_name'] , $dir.$nombreImagen)) {
	# code...
	print "<script>alert('Error: Imagen no guardada. No se publicó la noticia.')</script>";
	print"<script>location.href=\"redactarNoticia.php\"</script>";
}

$tituloDn=$_POST['tituloN'];
$seccionDn=$_POST['categoriaN'];
$autorDn=$_POST['autorN'];
$fechaHoraDn=date('Y-m-d H:i:s');
$contenidoDn=$_POST['contenidoN'];

$consulta= "insert into noticias (titulo, seccion, autor, fechaHora, contenido, imagen) values ('".$tituloDn."','".$seccionDn."','".$autorDn."','".$fechaHoraDn."','".$contenidoDn."','".$dir.$nombreImagen."')";

$resultado=$conexion->query($consulta);

print "
<!DOCTYPE html>
<html>
<head>
	<title>Publicar noticia</title>
	<meta charset=\"utf-8\">
	<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">
	<!--Estilos Bootstrap desde CDN-->
	<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css\" integrity=\"sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm\" crossorigin=\"anonymous\">

	<!--Paquete de fuentes e iconos-->
	<link rel=\"stylesheet\" href=\"https://use.fontawesome.com/releases/v5.7.1/css/all.css\" integrity=\"sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr\" crossorigin=\"anonymous\">
</head>
<body>
	<nav class=\"navbar navbar-expand-sm bg-dark navbar-dark fixed-top\">
		<div class=\"container\">
			<a href=\"#\" class=\"navbar-brand\">
				KAR+News
			</a>
			<button type=\"button\" class=\"navbar-toggler\" data-toggle=\"collapse\" data-target=\"#navbar-Collapse\">
				<span class=\"navbar-toggler-icon\"></span>
			</button>
			<div class=\"collapse navbar-collapse\" id=\"navbar-Collapse\">
				<ul class=\"navbar-nav ml-auto\">
					<li class=\"nav-item\">
						<a href=\"logout.php\" class=\"nav-link\">Cerrar Sesión</a>
					</li>
				</ul>
			</div>
		</div>
	</nav>

	<div class=\"d-flex flex-column p-5\">
";





if ($resultado) {
	# code...
	print "
	<p class=\"p-3\">Todo correcto!!</p>
		<div class=\"d-flex justify-content-center align-items-start flex-column align-self-center p-4\">
			<h1>La noticia fue publicada exitosamente!!</h1>
			<div class=\"align-self-center\">
				<h5>Puede encontrarla desde el portal y desde la base de datos</h5>
			</div>
			<a href=\"verificacion.php\" class=\"p-1\">
					<button type=\"button\" class=\"btn btn-dark btn-lg btn-block\">Regresar al menú</button>
			</a>
		</div>
	</div>
	";
} else {
	# code...
	print "
	<p class=\"p-3\">Algo ocurrió</p>
		<div class=\"d-flex justify-content-center align-items-start flex-column align-self-center p-4\">
			<h1>La noticia NO fue publicada</h1>
			<div class=\"align-self-center\">
				<h5>No se hicieron cambios</h5>
				<h5>$consulta</h5>
			</div>
			<a href=\"verificacion.php\" class=\"p-1\">
					<button type=\"button\" class=\"btn btn-dark btn-lg btn-block\">Volver al menú</button>
			</a>
		</div>
	</div>
	";
}


print "
	<!--Scripts desde CDN-->
	<script src=\"https://code.jquery.com/jquery-3.2.1.slim.min.js\" integrity=\"sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN\" crossorigin=\"anonymous\"></script>
	<script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js\" integrity=\"sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q\" crossorigin=\"anonymous\"></script>
	<script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js\" integrity=\"sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl\" crossorigin=\"anonymous\"></script>
	

</body>
</html>
";



?>