<?php
include("conexion.php");
$idDn=$_POST['iden'];

$consulta="select idNoticia from noticias where idNoticia=$idDn";

$resultado=$conexion->query($consulta);

print "
<!DOCTYPE html>
<html>
<head>
	<title>Modificar noticia</title>
	<meta charset=\"utf-8\">
	<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">
	<!--Estilos Bootstrap desde CDN-->
	<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css\" integrity=\"sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm\" crossorigin=\"anonymous\">

	<!--Paquete de fuentes e iconos-->
	<link rel=\"stylesheet\" href=\"https://use.fontawesome.com/releases/v5.7.1/css/all.css\" integrity=\"sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr\" crossorigin=\"anonymous\">
</head>
<body>
	<nav class=\"navbar navbar-expand-sm bg-dark navbar-dark fixed-top\">
		<div class=\"container\">
			<a href=\"#\" class=\"navbar-brand\">
				KAR+News
			</a>
			<button type=\"button\" class=\"navbar-toggler\" data-toggle=\"collapse\" data-target=\"#navbar-Collapse\">
				<span class=\"navbar-toggler-icon\"></span>
			</button>
			<div class=\"collapse navbar-collapse\" id=\"navbar-Collapse\">
				<ul class=\"navbar-nav ml-auto\">
					<li class=\"nav-item\">
						<a href=\"#deportes\" class=\"nav-link\">Deportes</a>
					</li>
					<li class=\"nav-item\">
						<a href=\"#cine\" class=\"nav-link\">Cine</a>
					</li>
					<li class=\"nav-item\">
						<a href=\"#videojuegos\" class=\"nav-link\">Videojuegos</a>
					</li>
				</ul>
			</div>
		</div>
	</nav>

	<div class=\"d-flex flex-column p-5\">
";


$ver=$resultado->fetch_array();

//print"<p>".$ver['idNoticia']."</p>";

if($ver['idNoticia']==null){
    //print"<p>No hay ID</p>";
    print "
	<p class=\"p-3\">Algo ocurrió</p>
		<div class=\"d-flex justify-content-center align-items-start flex-column align-self-center p-4\">
			<h1>No se encontró una noticia con el ID introducido</h1>
			<div class=\"align-self-center\">
				<h5>No se hicieron cambios</h5>
			</div>
			<a href=\"verificacion.php\" class=\"p-1\">
					<button type=\"button\" class=\"btn btn-dark btn-lg btn-block\">Volver al menú</button>
			</a>
		</div>
	</div>
	";
}
else{
    
   	print	"<div class=\"d-flex justify-content-center align-items-start flex-column align-self-center p-4\">
			<h1>Modificar noticia</h1>
			<div class=\"align-self-center\">
				<h5>Introduzca los nuevos valores para la noticia</h5>
			</div>
		</div>
		<div class=\"d-flex justify-content-center\">
			<form action=\"modificar.php\" method=\"post\" enctype=\"multipart/form-data\">
				<div class=\"form-group\">
				    <label for=\"exampleFormControlTextarea1\">Autor(a):</label>
                    <input class=\"form-control\" type=\"text\" name=\"autorN2\">
                    <input class=\"form-control\" type=\"hidden\" name=\"idN2\" value=\"".$ver['idNoticia']."\">
                </div>
				<div class=\"form-group\">
				    <label for=\"exampleFormControlInput1\">Título de la noticia:</label>
				    <input type=\"text\" class=\"form-control\" name=\"tituloN2\" REQUIRED>
				</div>
				<div class=\"form-group\">
				    <label for=\"exampleFormControlSelect1\">Categoría de la noticia:</label>
				    <select class=\"form-control\" name=\"categoriaN2\">
				      <option>Cine</option>
				      <option>Deportes</option>
				      <option>Videojuegos</option>
				    </select>
				</div>
				<div class=\"form-group\">
				    <label for=\"exampleFormControlTextarea1\">Texto de la noticia:</label>
				    <textarea class=\"form-control form-control-lg\" rows=\"10\" name=\"contenidoN2\" REQUIRED></textarea>
				</div>
				<div class=\"form-group\">
				    <label for=\"exampleFormControlFile1\">Imagen de la noticia:</label>
				    <input type=\"file\" class=\"form-control-file\"  name=\"image2\" REQUIRED>
				</div>
				<input type=\"submit\" class=\"btn btn-dark btn-lg btn-block\" value=\"Aplicar cambios\">
			</form>
		</div>
		
		
	</div>";
}

print "
	<!--Scripts desde CDN-->
	<script src=\"https://code.jquery.com/jquery-3.2.1.slim.min.js\" integrity=\"sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN\" crossorigin=\"anonymous\"></script>
	<script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js\" integrity=\"sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q\" crossorigin=\"anonymous\"></script>
	<script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js\" integrity=\"sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl\" crossorigin=\"anonymous\"></script>
	

</body>
</html>
";



?>