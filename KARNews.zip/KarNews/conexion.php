<?php
	$conexion= mysqli_connect("localhost","id1843873_karplus","12345","id1843873_karnews");
	if(!$conexion){
		print"<p>Algo salió mal con la conexión a la base de datos.</p>";
	}

?>
