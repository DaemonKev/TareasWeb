<?php
session_start();
$nombreAutor1="Ruben Alderete";
$passAutor1="alderete97";
$nombreAutor2="Humberto Gil";
$passAutor2="web502";
$nombreAutor3="Kevin Martinez";
$passAutor3="kev05";
$nombreAutor4="Ana Pacheco";
$passAutor4="web502";

if(isset($_POST['autorNombre'], $_POST['autorPass'])){
    $nombreObtenido = $_POST['autorNombre'];
    $contrasenaObtenida = $_POST['autorPass'];
}



print"
<!DOCTYPE html>
<html>
<head>
	<title>Menú de operaciones</title>
	<meta charset=\"utf-8\">
	<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">
	<!--Estilos Bootstrap desde CDN-->
	<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css\" integrity=\"sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm\" crossorigin=\"anonymous\">

	<!--Paquete de fuentes e iconos-->
	<link rel=\"stylesheet\" href=\"https://use.fontawesome.com/releases/v5.7.1/css/all.css\" integrity=\"sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr\" crossorigin=\"anonymous\">
</head>
<body>
	<nav class=\"navbar navbar-expand-sm bg-dark navbar-dark fixed-top\">
		<div class=\"container\">
			<a href=\"#\" class=\"navbar-brand\">
				KAR+News
			</a>
		</div>
	</nav>

";

if (isset($_SESSION['uname'])) {
	
	print"
	<div class=\"d-flex flex-column p-5\">
		<p class=\"p-3\">Bienvenido(a) ".$_SESSION['uname']."</p>";
	 
	print "
		<div class=\"d-flex justify-content-center align-items-start flex-column align-self-center p-4\">
			<h1>Administración de noticias</h1>
			<div class=\"align-self-center\">
				<h5>Seleccione la operación</h5>
			</div>
		</div>
		<div class=\"d-flex justify-content-center\">
			<form action=\"redactarNoticia.php\" method=\"get\">
			    <a href=\"consultar.php\" class=\"p-1\">
				    <button type=\"button\" class=\"btn btn-info btn-lg btn-block\">Consultar noticias guardadas</button>
				</a>
				<button type=\"submit\" class=\"btn btn-success btn-lg btn-block\">Redactar una nueva noticia
				    <input type=\"hidden\" name=\"nAutor\" value=\"$_SESSION[uname]\">
				</button>
				<a href=\"iniciamod.html\" class=\"p-1\">
    				<button type=\"button\" class=\"btn btn-warning btn-lg btn-block\">Modificar noticia existente</button>
    			</a>
    			<a href=\"iniciaelim.php\" class=\"p-1\">
				    <button type=\"button\" class=\"btn btn-danger btn-lg btn-block\">Eliminar una noticia</button>
				</a>
				<a href=\"logout.php\" class=\"p-1\">
					<button type=\"button\" class=\"btn btn-secondary btn-lg btn-block\">Cerrar sesión</button>
				</a>
			</form>
		</div>
		
		
	</div>
	";
	print "
	<!--Scripts desde CDN-->
	<script src=\"https://code.jquery.com/jquery-3.2.1.slim.min.js\" integrity=\"sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN\" crossorigin=\"anonymous\"></script>
	<script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js\" integrity=\"sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q\" crossorigin=\"anonymous\"></script>
	<script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js\" integrity=\"sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl\" crossorigin=\"anonymous\"></script>
</body>
</html>
";
}
else{
	if (($nombreObtenido==$nombreAutor1 && $contrasenaObtenida==$passAutor1)||($nombreObtenido==$nombreAutor2 && $contrasenaObtenida==$passAutor2)||($nombreObtenido==$nombreAutor3 && $contrasenaObtenida==$passAutor3)||($nombreObtenido==$nombreAutor4 && $contrasenaObtenida==$passAutor4)) {
		# code...
		
		$_SESSION['uname']=$nombreObtenido;
		print "<script>location.href='verificacion.php'</script>";
	}
	else{
	   
        print"<script>alert('Usuario y/o contraseña incorrectos')</script>";
		print "<script>location.href='logout.php'</script>";
		
	}
}

$db=null;
?>