<?php
session_start();

if (isset($_SESSION['uname'])) {
	session_destroy();
	print"<script>location.href=\"loginAutores.html\"</script>";
}
else{
	print"<script>location.href=\"loginAutores.html\"</script>";
}
 	

?>