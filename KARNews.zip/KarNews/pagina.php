<?php
include("conexion.php");
$idDn=$_POST['iden'];

$consulta= "select * from noticias where idNoticia=$idDn";

$resultado=$conexion->query($consulta);

if ($resultado) {

  print "
  <!DOCTYPE html>
<!-- saved from url=(0049)https://getbootstrap.com/docs/4.2/examples/blog/# -->
<html lang=\"en\"><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">
    
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">
    <title>KAR+NEWS</title>

    <!-- Bootstrap core CSS -->
<link href=\"./archivos_pagina/bootstrap.min.css\" rel=\"stylesheet\" integrity=\"sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS\" crossorigin=\"anonymous\">
<link rel=\"stylesheet\" href=\"https://use.fontawesome.com/releases/v5.7.1/css/all.css\" integrity=\"sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr\" crossorigin=\"anonymous\">

    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>
    <!-- Custom styles for this template -->
    <link href=\"./archivos_pagina/css\" rel=\"stylesheet\">
    <!-- Custom styles for this template -->
    <link href=\"./archivos_pagina/blog.css\" rel=\"stylesheet\">
  </head>
  <body>
    <div class=\"container\">
    <header class=\"blog-header py-3\">
      <div class=\"row flex-nowrap justify-content-between align-items-center\">
        <div class=\"col-4 pt-1\">
          <a class=\"text-muted\" href=\"#\"></a>
        </div>
        <div class=\"col-4 text-center\">
          <a class=\"blog-header-logo text-dark\" href=\"videojuegos.php\">KAR+News</a>
        </div>
        <div class=\"col-4 d-flex justify-content-end align-items-center\">
          <a class=\"btn btn-sm btn-outline-secondary\" href=\"loginAutores.html\">Administración</a>
        </div>
      </div>
    </header>

  <div class=\"nav-scroller py-1 mb-2\">
    <nav class=\"nav d-flex justify-content-around \">
      <a class=\"p-2 text-muted\" href=\"videojuegos.php\">Videojuegos</a>
      <a class=\"p-2 text-muted\" href=\"cine.php\">Cine</a>
      <a class=\"p-2 text-muted\" href=\"deportes.php\">Deportes</a>
    </nav>
  </div>

  <div class=\"row mb-2\">
    <div class=\"col-md-6\">
    </div>
    <div class=\"col-md-6\">
    </div>
  </div>
</div>

<main role=\"main\" class=\"container\">
  <div class=\"row\">
    <div class=\"col-md-12 blog-main\">
      <aside class=\"col-md-12 blog-sidebar\">
        <div class=\"p-3 mb-3 bg-light rounded\">";

	while ($fila=$resultado->fetch_array()) {
    print "           <div class=\"card border-light mb-3\">
              <div class=\"card-body\">
                <h1 class=\"card-title\">".$fila['titulo']."</h1>
                <p class=\"card-text\">Redactado por ".$fila['autor']." en ".$fila['fechaHora']." </p>
                <p class=\"card-text\">".$fila['cantidadLikes']." Likes</p>
                <form action=\"aumentolikes.php\" method=\"post\">
                  <div class=\"form-group\">
                      <input class=\"form-control\" type=\"hidden\" name=\"iden\" value=\"".$fila['idNoticia']."\">
                  </div>
                    <input type=\"submit\" class=\"btn  btn-primary btn-md\" value=\"Me gusta\">
                    <i class=\"far fa-hand-point-right\"></i>
                  </input>
                </form>
              </div>
              <img class=\"card-img-bottom\" src=\"".$fila['imagen']."\" alt=\"Card image cap\">
            </div>

           <!--Aqui va la otra tarjeta -->
          <h3 class=\"card-text\">".$fila['contenido']."</h3>
          <br>
          <br>
          <br>
          <br>
          <h5 class=\"card-text\">Y a ti, qué te pareció la noticia?</h5>
          <form action=\"comentar.php\" method=\"post\">
                  <div class=\"form-group\">
                      <textarea class=\"form-control form-control-lg\" rows=\"2\" name=\"contenidoC\"></textarea>
                      <input class=\"form-control\" type=\"hidden\" name=\"iden\" value=\"".$fila['idNoticia']."\">
                  </div>
                    <input type=\"submit\" class=\"btn  btn-dark btn-md\" value=\"Comentar\">
                  </input>
          </form>
          <br>
          <br>
          <h5 class=\"card-text\">Comentarios recientes:</h5>";

	}

	
	$consulta2= "select * from comentarios where idNoticiaComentada=$idDn order by fecha desc";

	$resultado2=$conexion->query($consulta2);

	while ($filaR=$resultado2->fetch_array()) {
		print "<p class=\"card-text\">Usuario".$filaR['idComentario']." dijo el dia y hora ".$filaR['fecha'].":</p>
          <textarea class=\"form-control form-control-lg\" rows=\"1\" value=\"Contenido del comentario\" readonly>".$filaR['contenidoComentario']."</textarea>";
	}

} else {
	print "
	<p class=\"p-3\">Algo ocurrió</p>
		<div class=\"d-flex justify-content-center align-items-start flex-column align-self-center p-4\">
			<h1>Hubo un error en la operación</h1>
			<div class=\"align-self-center\">
				<h5>$consulta</h5>
			</div>
			<a href=\"videojuegos.php\" class=\"p-1\">
					<button type=\"button\" class=\"btn btn-dark btn-lg btn-block\">Volver al inicio</button>
			</a>
		</div>
	</div>
	";
}

print "
</div>
  </aside><!-- /.blog-sidebar -->

    </div><!-- /.blog-main -->

  </div><!-- /.row -->

</main><!-- /.container -->

<footer class=\"blog-footer\">
  <p>KAR+NEWS y sus logos son propiedad de KAR+ y de todos sus miembros. Todos los derechos reservados. UTM 2018.</p>
</footer>
<script src=\"./archivos_pagina/jquery-3.3.1.slim.min.js.descarga\" integrity=\"sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo\" crossorigin=\"anonymous\"></script>
      <script>window.jQuery || document.write('<script src=\"/docs/4.2/assets/js/vendor/jquery-slim.min.js\"><\/script>')</script><script src=\"./archivos_pagina/bootstrap.bundle.min.js.descarga\" integrity=\"sha384-zDnhMsjVZfS3hiP7oCBRmfjkQC4fzxVxFhBx8Hkz2aZX8gEvA/jsP3eXRCvzTofP\" crossorigin=\"anonymous\"></script>

</body>
</html>";

?>