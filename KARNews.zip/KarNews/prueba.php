<!DOCTYPE html>
<!-- saved from url=(0049)https://getbootstrap.com/docs/4.2/examples/blog/# -->
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>KAR+NEWS</title>

    <!-- Bootstrap core CSS -->
<link href="./archivos_pagina/bootstrap.min.css" rel="stylesheet" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">

    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>
    <!-- Custom styles for this template -->
    <link href="./archivos_pagina/css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="./archivos_pagina/blog.css" rel="stylesheet">
  </head>
  <body>
    <div class="container">
    <header class="blog-header py-3">
      <div class="row flex-nowrap justify-content-between align-items-center">
        <div class="col-4 pt-1">
          <a class="text-muted" href="https://getbootstrap.com/docs/4.2/examples/blog/#"></a>
        </div>
        <div class="col-4 text-center">
          <a class="blog-header-logo text-dark" href="https://getbootstrap.com/docs/4.2/examples/blog/#">KAR+News</a>
        </div>
        <div class="col-4 d-flex justify-content-end align-items-center">
          <a class="btn btn-sm btn-outline-secondary" href="https://getbootstrap.com/docs/4.2/examples/blog/#">Administración</a>
        </div>
      </div>
    </header>

  <div class="nav-scroller py-1 mb-2">
    <nav class="nav d-flex justify-content-around ">
      <a class="p-2 text-muted" href="videojuegos.php">Videojuegos</a>
      <a class="p-2 text-muted" href="cine.php">Cine</a>
      <a class="p-2 text-muted" href="deportes.php">Deportes</a>
    </nav>
  </div>

  <div class="row mb-2">
    <div class="col-md-6">
    </div>
    <div class="col-md-6">
    </div>
  </div>
</div>

<main role="main" class="container">
  <div class="row">
    <div class="col-md-8 blog-main">
      <aside class="col-md-12 blog-sidebar">
        <div class="p-3 mb-3 bg-light rounded">
          <h4 class="font-italic text-dark ">Noticias de videojuegos destacadas:</h4>


            <div class="card border-secondary mb-3">
              <img class="card-img-top" src="Adicionales/prueba.jpg" alt="Card image cap">
              <div class="card-body">
                <h4 class="card-title">Aquí va el título</h4>
                <p class="card-text">X Likes.</p>
                <form action="pagina.php" method="post">
                  <div class="form-group">
                      <input class="form-control" type="hidden" name="iden" value="#">
                  </div>
                    <input type="submit" class="btn  btn-dark btn-md" value="Seguir leyendo...">
                  </input>

                </form>
              </div>
            </div>

           <!--Aqui va la otra tarjeta -->


        </div>





      </aside><!-- /.blog-sidebar -->

    </div><!-- /.blog-main -->

    <aside class="col-md-4 blog-sidebar">
      <div class="p-3 mb-3 bg-secondary rounded">
        <h4 class="font-italic text-light">Lo más reciente: </h4>



        <div class="card flex-md-row mb-3 shadow-sm h-sm-250 bg-dark">
          <div class="card-body d-flex flex-column align-items-start ">
              <h4 class="mb-0 text-white">Featured post lelelele ok kjasbd</h4>
              <div class="mb-1 text-white">Nov 12</div>
              <form action="buscarelim.php" method="post">
                <div class="form-group">
                    <input class="form-control" type="hidden" name="iden" value="">
                </div>
                <input type="submit" class="btn btn-primary btn-sm" value="Seguir leyendo...">
              </form>
          </div>
        </div>

        <!--Aqui va la otra tarjeta -->
        <div class="card flex-md-row mb-3 shadow-sm h-sm-250 bg-dark">
          <div class="card-body d-flex flex-column align-items-start ">
              <h4 class="mb-0 text-white">Featured post lelelele ok kjasbd</h4>
              <div class="mb-1 text-white">Nov 12</div>
              <form action="#" method="post">
                <div class="form-group">
                    <input class="form-control" type="hidden" name="iden" value="#">
                </div>
                <input type="submit" class="btn btn-primary btn-sm" value="Seguir leyendo...">
              </form>
          </div>
        </div>


      </div>
    </aside><!-- /.blog-sidebar -->

  </div><!-- /.row -->

</main><!-- /.container -->

<footer class="blog-footer">
  <p>KAR+NEWS y sus logos son propiedad de KAR+ y de todos sus miembros. Todos los derechos reservados. UTM 2018.</p>
</footer>
<script src="./archivos_pagina/jquery-3.3.1.slim.min.js.descarga" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
      <script>window.jQuery || document.write('<script src="/docs/4.2/assets/js/vendor/jquery-slim.min.js"><\/script>')</script><script src="./archivos_pagina/bootstrap.bundle.min.js.descarga" integrity="sha384-zDnhMsjVZfS3hiP7oCBRmfjkQC4fzxVxFhBx8Hkz2aZX8gEvA/jsP3eXRCvzTofP" crossorigin="anonymous"></script>

</body>
</html>