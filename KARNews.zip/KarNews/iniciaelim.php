<!DOCTYPE html>
<html>
<head>
	<title>Eliminar noticia</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<!--Estilos Bootstrap desde CDN-->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

	<!--Paquete de fuentes e iconos-->
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
</head>
<body>
	<nav class="navbar navbar-expand-sm bg-dark navbar-dark fixed-top">
		<div class="container">
			<a href="#" class="navbar-brand">
				KAR+News
			</a>
			<button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbar-Collapse">
				<span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="navbar-Collapse">
				<ul class="navbar-nav ml-auto">
					<li class="nav-item">
						<a href="verificacion.php" class="nav-link">Regresar al menú</a>
					</li>
				</ul>
			</div>
		</div>
	</nav>

	<div class="d-flex flex-column p-5">
		<div class="d-flex justify-content-center align-items-start flex-column align-self-center p-4">
			<h1>Eliminar una noticia</h1>
			<div class="align-self-center">
				<h5>Introduzca el ID de la noticia que desee eliminar</h5>
			</div>
		</div>
		<div class="d-flex justify-content-center">
			<form action="buscarelim.php" method="post">
				<div class="form-group">
				    <label for="exampleFormControlTextarea1">ID:</label>
                    <input class="form-control" type="number" name="iden" required>
				</div>
				<input type="submit" class="btn btn-dark btn-lg btn-block" value="Buscar">
			</form>
		</div>
		
		
	</div>
