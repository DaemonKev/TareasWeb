import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import firebase from '../Firebase';
import { BrowserRouter as Router, Route, Link } from "react-router-dom";

import Videojuegos from "./Videojuegos";
import Cine from "./Cine";
import Deportes from "./Deportes";

export default class Menu extends Component {
  render() {
    return (
      <Router>
        <div class="nav-scroller py-1 mb-2">
          <nav class="nav d-flex justify-content-around ">
            <Link to="/videojuegos" className="p-2 text-muted">Videojuegos</Link>
            <Link to="/cine" className="p-2 text-muted">Cine</Link>
            <Link to="/deportes" className="p-2 text-muted">Deportes</Link>
          </nav>
        </div>
        <Route path="/videojuegos" exact component={Videojuegos}/>
        <Route path="/cine" component={Cine}/>
        <Route path="/deportes" component={Deportes}/>
      </Router>
    );
  }
}