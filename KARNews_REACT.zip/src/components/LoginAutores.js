import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import firebase from '../Firebase';
import { Link } from 'react-router-dom';

import MenuCRUD from "./MenuCRUD";

export default class LoginAutores extends Component {
  constructor(props){
    super(props);
    this.login = this.login.bind(this);
    this.OnChangeCorreo = this.OnChangeCorreo.bind(this);
    this.OnChangePass = this.OnChangePass.bind(this);
    /*
    firebase.auth().onAuthStateChanged(function(usuario){
      if(usuario){
        firebase.auth().signOut();
        console.log("Sesión cerrada");
      }
      else{
        console.log("Ningún usuario accedió");
      }
    });
    */
    this.state = {
      correo : '',
      pass: '',
      banderaAuth: 0
    }

  }
  OnChangeCorreo(e){
    this.setState({
      correo: e.target.value
    });
  }

  OnChangePass(e){
    this.setState({
      pass: e.target.value
    });
  }
  login(e){
    e.preventDefault();
    firebase.auth().signInWithEmailAndPassword(this.state.correo, this.state.pass).then((u)=>{
      this.setState({
        banderaAuth: 1,
      });
      console.log("bienvenido");
    })
    .catch((error) => {
      this.setState({
        banderaAuth: 0,
      });
      alert("Usuario o contraseña incorrectos");
      console.log("Error");
    });
  }
  render() {
    if(this.state.banderaAuth==0){
      return (
        <div className="d-flex flex-column p-5">
          <div className="d-flex justify-content-center align-items-start flex-column align-self-center p-4">
            <h1>Administración de noticias</h1>
            <div className="align-self-center">
              <h5>Verificación de usuarios</h5>
            </div>
          </div>
          
          <div className="d-flex justify-content-center">
            <form onSubmit = {this.login}>
              <div className="form-group">
                <input type="email" className=" form-control form-control-lg" placeholder="Correo de Autor(a)" name="autorNombre" required onChange={this.OnChangeCorreo} value={this.state.correo}></input>
              </div>
              <div className="form-group">
                <input type="password" className=" form-control form-control-lg" placeholder="Contraseña" name="autorPass" required onChange={this.OnChangePass} value={this.state.pass}></input>
              </div>
              <input type="submit" className="btn btn-dark btn-lg btn-block" value="Ingresar"></input>
            </form>
          </div>
        </div>
      );
    }
    else{
      return (
        <MenuCRUD/>
      );
    }
  }
}