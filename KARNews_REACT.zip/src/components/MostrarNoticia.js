import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import firebase from '../Firebase';
import { Link } from 'react-router-dom';

export default class MostrarNoticia extends Component {
  
  constructor(props) {
    super(props);
    
    this.OnActualizarLikes = this.OnActualizarLikes.bind(this);
    this.refrescarLikes = this.refrescarLikes.bind(this);
    this.AddComentario = this.AddComentario.bind(this);
    this.OnChangeContenidoComentario = this.OnChangeContenidoComentario.bind(this);
    this.refrescarComentarios = this.refrescarComentarios.bind(this);
    this.state = {
      NoticiaTitulo : '',
      NoticiaSeccion : '',
      NoticiaAutor : '',
      NoticiaContenido : '',
      NoticiaImagen : '',
      NoticiaFechaFormateada: '',
      NoticiaCantidadLikes: '',
      ComentarioContenido: '',
      Comentarios: [] 
    }
  }

  componentDidMount() {
    var actual = window.location+'';
    //Se realiza la división de la URL
    var split = actual.split("/");
    //Se obtiene el ultimo valor de la URL
    var id = split[split.length-1];
    console.log(id);

    let docRef = firebase.firestore().collection('noticias').doc(id);

    docRef.get().then((doc) => {
      if(doc.exists){
        this.setState({
          NoticiaTitulo: doc.data().titulo,
          NoticiaSeccion: doc.data().seccion,
          NoticiaAutor: doc.data().autor,
          NoticiaContenido: doc.data().contenido,
          NoticiaImagen: doc.data().linkImagen,
          NoticiaFechaFormateada: doc.data().fechaFormateada,
          NoticiaCantidadLikes: doc.data().cantidadLikes
        })
      }else{
        console.log("El documento no existe");
      }
    }).catch((error) => 
      {console.log(error);
    })


    var comentariosTodos = firebase.firestore().collection('comentarios').where('idNoticiaComentada', '==', id).orderBy('fecha','desc');
    comentariosTodos.get().then((snapShots) => {
      this.setState({
        Comentarios: snapShots.docs.map(doc => {
          return{id: doc.id, data: doc.data()}
        })
      })
    }, error => {
      console.log(error)
    });
  }
  
  refrescarLikes(){
    
    var actual = window.location+'';
    //Se realiza la división de la URL
    var split = actual.split("/");
    //Se obtiene el ultimo valor de la URL
    var id = split[split.length-1];
    console.log(id);

    let docRef = firebase.firestore().collection('noticias').doc(id);

    docRef.get().then((doc) => {
      if(doc.exists){
        this.setState({
          NoticiaTitulo: doc.data().titulo,
          NoticiaSeccion: doc.data().seccion,
          NoticiaAutor: doc.data().autor,
          NoticiaContenido: doc.data().contenido,
          NoticiaImagen: doc.data().linkImagen,
          NoticiaFechaFormateada: doc.data().fechaFormateada,
          NoticiaCantidadLikes: doc.data().cantidadLikes
        })
      }else{
        console.log("El documento no existe");
      }
    }).catch((error) => 
      {console.log(error);
    })
  }

  OnActualizarLikes(e){
    e.preventDefault();
    var gustos = +this.state.NoticiaCantidadLikes;
    gustos+=1;

    var actual = window.location+'';
    //Se realiza la división de la URL
    var split = actual.split("/");
    //Se obtiene el ultimo valor de la URL
    var id = split[split.length-1];
    //console.log("lele "+id);
    const obj = {
      titulo: this.state.NoticiaTitulo,
      seccion: this.state.NoticiaSeccion,
      autor: this.state.NoticiaAutor,
      contenido: this.state.NoticiaContenido,
      linkImagen: this.state.NoticiaImagen,
      fechaFormateada: this.state.NoticiaFechaFormateada,
      cantidadLikes: gustos
    };

    var referencia = firebase.firestore().collection('noticias').doc(id);

    referencia.update(obj)
    .then(()=>{
      console.log("Likes actualizados");
      this.refrescarLikes();
    }).catch((error) =>{
      console.log(error);
    })
  }

  refrescarComentarios(){
    this.setState({
      ComentarioContenido: ''
    });
    var actual = window.location+'';
    //Se realiza la división de la URL
    var split = actual.split("/");
    //Se obtiene el ultimo valor de la URL
    var id = split[split.length-1];
    //console.log("lele "+id);
    var comentariosTodos = firebase.firestore().collection('comentarios').where('idNoticiaComentada', '==', id).orderBy('fecha','desc');
    comentariosTodos.get().then((snapShots) => {
      this.setState({
        Comentarios: snapShots.docs.map(doc => {
          return{id: doc.id, data: doc.data()}
        })
      })
    }, error => {
      console.log(error)
    });
  }

  AddComentario(e){
    e.preventDefault();

    var fecha2 = new Date();
    var fecha2Dia = fecha2.getDate();
    var fecha2Mes = fecha2.getMonth();
    var fecha2Anio = fecha2.getFullYear();
    var fecha2Hora = fecha2.getHours();
    var fecha2Minutos = fecha2.getMinutes();
    var fecha2String = fecha2Dia.toString() + "/" + fecha2Mes.toString() + "/" + fecha2Anio.toString() + " - "+ fecha2Hora.toString() + " : " + fecha2Minutos.toString();

    var actual = window.location+'';
    //Se realiza la división de la URL
    var split = actual.split("/");
    //Se obtiene el ultimo valor de la URL
    var id = split[split.length-1];
    //console.log("lele "+id);

    const obj = {
      idNoticiaComentada: id,
      contenidoComentario: this.state.ComentarioContenido,
      fecha: firebase.firestore.FieldValue.serverTimestamp(),
      fechaFormateada: fecha2String
    };

    
    var referencia = firebase.firestore().collection('comentarios');

    referencia.add(obj)
    .then(function(docRef) {
      //alert("Comentario Publicado Exitosamente");
      console.log("Documento escrito con ID: ", docRef.id);
      
    })
    .catch(function(error) {
      console.error("Error agregando documento: ", error);
    });
    this.refrescarComentarios();
  }

  OnChangeContenidoComentario(e){
    this.setState({
      ComentarioContenido : e.target.value
    })
  }

  render() {
    //const {noticiaDatos} = this.state;
    //const {noticiaComentarios} = this.state;
    return(
      <main role='main' className="container">
        <div className='row'>
          <div className='col-md-12 blog-main'>
            <aside className='col-md-12 blog-sidebar'>
              <div className='p-3 mb-3 bg-light rounded'>
                <div className='card border-light mb-3' >
                  <div className='card-body'>
                    <h1 className='card-title'>{this.state.NoticiaTitulo}</h1>
                    <p className='card-text'>Redactado por {this.state.NoticiaAutor} en : {this.state.NoticiaFechaFormateada}</p>
                    <p className='card-text'>Likes: {this.state.NoticiaCantidadLikes}</p>
                    <button className="btn btn-primary btn-sm" onClick={this.OnActualizarLikes}>Me Gusta</button>
                  </div>
                  <img className='card-img-bottom' src={this.state.NoticiaImagen} alt='Card image cap'></img>
                  <h3 className='card-text'>{this.state.NoticiaContenido}</h3>
                  <br></br>
                  <br></br>

                  <div className='form-group'>
                    <br></br>
                    <br></br>
                    <h5 className='card-text'>Y a ti, qué te pareció la noticia?</h5>
                    
                  </div>
                  
                  <form onSubmit={this.AddComentario}>
                    <div className='form-group'>
                      <textarea className='form-control form-control-lg' rows='2' onChange={this.OnChangeContenidoComentario} value={this.state.ComentarioContenido}/>
                    </div>
                    <input type='submit' className='btn  btn-dark btn-md' value='Comentar'/>
                  </form>
                  
                  <div className='form-group'>
                    <br></br>
                    <br></br>
                    <h5>Comentarios Recientes:</h5>
                    { this.state.Comentarios && this.state.Comentarios!== undefined ? this.state.Comentarios.map((comentario, key) => (
                      <div key={key}>
                        <p className='card-text' key={key}>El usuario {comentario.id} en {comentario.data.fechaFormateada} dijo :</p>
                        <textarea className='form-control form-control-lg' value={comentario.data.contenidoComentario} readOnly={true}/>
                      </div>
                      )): null
                    }
                    <br></br>
                    <br></br>
                  </div>
                </div>
              </div>
            </aside>
          </div>
        </div>
        <footer className='footer'>
          <p align='center'>KAR+NEWS y sus logos son propiedad de KAR+ y de todos sus miembros. Todos los derechos reservados. UTM 2018.</p>
        </footer>
      </main>
    );
  }
}