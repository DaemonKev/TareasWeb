import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import firebase from '../Firebase';
import { Link } from 'react-router-dom';

export default class Videojuegos extends Component {
  
  state ={
    noticiasVideojuegos: [],
    noticiasNuevas: []
  }
  componentDidMount(){
    var videos = firebase.firestore().collection('noticias').where('seccion','==','Videojuegos').orderBy('cantidadLikes', 'desc').limit(9);
    var recientes = firebase.firestore().collection("noticias").orderBy('fecha', 'desc').limit(6);
    var ref = firebase.firestore().collection('noticias');
    videos.get().then((snapShots) => {
      this.setState({
        noticiasVideojuegos: snapShots.docs.map(doc => {
          return{id: doc.id, data: doc.data()}
        })
      })
    }, error => {
      console.log(error)
    });
    recientes.get().then((snapShots) => {
      this.setState({
        noticiasNuevas: snapShots.docs.map(doc => {
          return{id: doc.id, data: doc.data()}
        })
      })
    }, error => {
      console.log(error)
    });
  }
  render() {
    const {noticiasVideojuegos} = this.state;
    const {noticiasNuevas} = this.state;
    return(
      <main role='main' className="container">
        <div className='row'>
          <div className='col-md-8 blog-main'>
            <aside className='col-md-12 blog-sidebar'>
              <div className='p-3 mb-3 bg-light rounded'>
                <h4 className='font-italic text-dark'>Noticias de Videojuegos destacadas:</h4>
                { noticiasVideojuegos && noticiasVideojuegos!== undefined ? noticiasVideojuegos.map((noticia, key) => (
                  <div className='card border-secondary mb-3' key={key}>
                    <img className='card-img-top' src={noticia.data.linkImagen} alt='Card image cap'></img>
                    <div className='card-body'>
                      <h4>{noticia.data.titulo}</h4>
                      <p className='card-text'>Likes: {noticia.data.cantidadLikes}</p>
                      <Link to={"/show/"+noticia.id} className='btn  btn-dark btn-md'>Seguir leyendo...</Link>
                    </div>
                  </div>
                  )): null
                }
              </div>
            </aside>
          </div>
          <aside className='col-md-4 blog-sidebar'>
            <div className='p-3 mb-3 bg-secondary rounded'>
              <h4 className='font-italic text-light'>Lo más reciente:</h4>
              { noticiasNuevas && noticiasNuevas!== undefined ? noticiasNuevas.map((noticia, key) => (
                  <div className='card flex-md-row mb-3 shadow-sm h-sm-250 bg-dark' key={key}>
                  <div className='card-body d-flex flex-column align-items-start'>
                    <h4 className='mb-0 text-white'>{noticia.data.titulo}</h4>
                    <p className='mb-1 text-white'>{noticia.data.fechaFormateada}</p>
                    <Link to={"/show/"+noticia.id} className='btn btn-primary btn-sm'>Seguir leyendo...</Link>
                  </div>
                </div>
                )): null
              }
            </div>
          </aside>
        </div>
        <footer className='footer'>
          <p align='center'>KAR+NEWS y sus logos son propiedad de KAR+ y de todos sus miembros. Todos los derechos reservados. UTM 2018.</p>
        </footer>
      </main>
      
    );
    
    /*
    firebase.auth().onAuthStateChanged(function(usuario){
      if(usuario){
        firebase.auth().signOut();
        console.log("Sesión cerrada");
      }
      else{
        console.log("Ningún usuario accedió");
      }
    });
    */
   /*
   if(this.state.noticiasVideojuegos.length>0){
    return(
      <main role='main' className="container">
        <div className='row'>
          <div className='col-md-8 blog-main'>
            <aside className='col-md-12 blog-sidebar'>
              <div className='p-3 mb-3 bg-light rounded'>
                <h4 className='font-italic text-dark'>Noticias de Videojuegos destacadas:</h4>
                { noticiasVideojuegos && noticiasVideojuegos!== undefined ? noticiasVideojuegos.map((noticia, key) => (
                  <div className='card border-secondary mb-3' key={key}>
                    <img className='card-img-top' src={noticia.linkImagen} alt='Card image cap'></img>
                    <div className='card-body'>
                      <h4>{noticia.titulo}</h4>
                      <p className='card-text'>Likes: {noticia.cantidadLikes}</p>

                    </div>
                  </div>
                  )): null
                }
              </div>
            </aside>
          </div>
        </div>
      </main>
    );
   }
   else{
    return (
      <div class="d-flex flex-column p-5">
        <div class="d-flex justify-content-center align-items-start flex-column align-self-center p-4">
          <h1>Videojuegos</h1>
        </div>
      </div>
    );
   }
   */
  }
}