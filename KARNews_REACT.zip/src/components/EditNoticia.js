import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import firebase from '../Firebase';
import { Link } from 'react-router-dom';

export default class EditNoticia extends Component {
  constructor(props) {
    super(props);
    this.onChangeNoticiaTitulo = this.onChangeNoticiaTitulo.bind(this);
    this.onChangeNoticiaSeccion = this.onChangeNoticiaSeccion.bind(this);
    this.onChangeNoticiaAutor = this.onChangeNoticiaAutor.bind(this);
    this.onChangeNoticiaContenido = this.onChangeNoticiaContenido.bind(this);
    this.onChangeNoticiaImagen = this.onChangeNoticiaImagen.bind(this);

    this.onSubmit = this.onSubmit.bind(this);

    this.state = {
      NoticiaTitulo : '',
      NoticiaSeccion : '',
      NoticiaAutor : '',
      NoticiaContenido : '',
      NoticiaImagen : '',
    }
  }

  componentDidMount() {
      var actual = window.location+'';
    //Se realiza la división de la URL
    var split = actual.split("/");
    //Se obtiene el ultimo valor de la URL
    var id = split[split.length-1];
    console.log(id);

    let docRef = firebase.firestore().collection('noticias').doc(id);

    docRef.get().then((doc) => {
      if(doc.exists){
        this.setState({
          NoticiaTitulo: doc.data().titulo,
          NoticiaSeccion: doc.data().seccion,
          NoticiaAutor: doc.data().autor,
          NoticiaContenido: doc.data().contenido,
          NoticiaImagen: doc.data().linkImagen,
        })
      }else{
        console.log("El documento no existe");
      }
    }).catch((error) => 
      {console.log(error);
    })
    /*
    this.setState({

    });
    */
  }

  onChangeNoticiaTitulo(e) {
    this.setState({
      NoticiaTitulo: e.target.value
    });
  }
  onChangeNoticiaSeccion(e) {
    this.setState({
      NoticiaSeccion: e.target.value
    })  
  }
  onChangeNoticiaAutor(e) {
    this.setState({
      NoticiaAutor: e.target.value
    })
  }
  onChangeNoticiaContenido(e){
    this.setState({
      NoticiaContenido: e.target.value
    });
  }

  onChangeNoticiaImagen(e){
    this.setState({
      NoticiaImagen: e.target.value
    });
  }

  onSubmit(e){
    e.preventDefault();
    var actual = window.location+'';
    //Se realiza la división de la URL
    var split = actual.split("/");
    //Se obtiene el ultimo valor de la URL
    var id = split[split.length-1];
    //console.log("lele "+id);
    const obj = {
      titulo: this.state.NoticiaTitulo,
      seccion: this.state.NoticiaSeccion,
      autor: this.state.NoticiaAutor,
      contenido: this.state.NoticiaContenido,
      linkImagen: this.state.NoticiaImagen,
    };

    var referencia = firebase.firestore().collection('noticias').doc(id);

    referencia.update(obj)
    .then(()=>{
      alert("Noticia actualizada");
      console.log("Noticia actualizada");
    }).catch((error) =>{
      console.log(error);
    })
    
  }
 
 
  render() {

    return (
        <div style={{ marginTop: 10, marginLeft: 50, marginRight: 50 }}>
            <h3 align="center">Editar noticia</h3>
            <form onSubmit={this.onSubmit}>
                <div className="form-group">
                    <label>Título:  </label>
                    <input 
                      type="text" 
                      className="form-control" 
                      value={this.state.NoticiaTitulo}
                      onChange={this.onChangeNoticiaTitulo}
                      />
                </div>
                <div className="form-group">
                    <label>Sección: </label>
                    <select className='form-control' onChange={this.onChangeNoticiaSeccion} value={this.state.NoticiaSeccion}>
                      <option value="Videojuegos">Videojuegos</option>
                      <option value="Deportes">Deportes</option>
                      <option value="Cine">Cine</option>
                    </select>
                </div>
                <div className="form-group">
                    <label>Autor: </label>
                    <input type="text" 
                      className="form-control"
                      value={this.state.NoticiaAutor}
                      onChange={this.onChangeNoticiaAutor}
                      />
                </div>
                <div className="form-group">
                      <label>Contenido: </label>
                      <textarea className="form-control"
                        value={this.state.NoticiaContenido}
                        onChange={this.onChangeNoticiaContenido}/>
                  </div>
                  <div className="form-group">
                      <label>Imagen: </label>
                      <input type="text" 
                        className="form-control"
                        value={this.state.NoticiaImagen}
                        onChange={this.onChangeNoticiaImagen}
                        />
                  </div>
                <div className="form-group">
                    <input type="submit" 
                      value="Actualizar Noticia" 
                      className="btn btn-primary"/>
                </div>
            </form>
        </div>
    )
  }
}