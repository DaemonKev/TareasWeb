import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import firebase from '../Firebase';
import { Link } from 'react-router-dom';



export default class MenuCRUD extends Component {
  state = {
    noticias : []
  }
  
  refrescar(){
    this.ref = firebase.firestore().collection('noticias');
    this.ref.get().then((snapShots) => {
      this.setState({
        noticias: snapShots.docs.map(doc => {
          return{id: doc.id, data: doc.data()}
        })
      })
    }, error => {
      console.log(error)
    });
  }
	
  componentDidMount(){
    this.ref = firebase.firestore().collection('noticias');
    this.ref.get().then((snapShots) => {
      this.setState({
        noticias: snapShots.docs.map(doc => {
          return{id: doc.id, data: doc.data()}
        })
      })
    }, error => {
      console.log(error)
    });
  }

  delete(id){
    var referencia = firebase.firestore().collection('noticias').doc(id);
    referencia.delete()
    .then(()=>{
      console.log("Eliminado");
      this.refrescar();
    }).catch((error) =>{
      console.log(error);
    })
  }
  
  render() {
    const {noticias} = this.state;
    return (
      <div style={{ marginTop: 10, marginLeft: 50, marginRight: 50 }}>
        <h3 align="center">Lista de Noticias</h3>
        <Link to={"/create"} className="btn btn-info" align="rigth">Publicar Noticia</Link>
        <table className="table table-striped" style={{ marginTop: 20 }}>
          <thead>
            <tr>
              <th>ID</th>
              <th>Título</th>
              <th>Sección</th>
              <th>Autor</th>
              <th colSpan="2">Action</th>
            </tr>
          </thead>
          <tbody>
            { noticias && noticias!== undefined ? noticias.map((noticia, key) => (
              <tr key={key}>
                <td>{noticia.id}</td>
                <td>{noticia.data.titulo}</td>
                <td>{noticia.data.seccion}</td>
                <td>{noticia.data.autor}</td>
                <td><Link to={"/edit/"+noticia.id} className="btn btn-primary">Editar</Link></td>
                <td>
                  <button onClick={() => this.delete(noticia.id)} className="btn btn-danger">Eliminar</button>
                </td>
              </tr>
              )): null}
          </tbody>
        </table>
      </div>
    );
  }
}