import React from 'react';
import logo from './logo.svg';
import './App.css';
import "bootstrap/dist/css/bootstrap.min.css";
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import firebase from './Firebase';

import LoginAutores from "./components/LoginAutores";
import Videojuegos from "./components/Videojuegos";
import Cine from "./components/Cine";
import Deportes from "./components/Deportes";
import Menu from "./components/Menu";
import EditNoticia from "./components/EditNoticia";
import CrearNoticia from "./components/CrearNoticia";
import MostrarNoticia from "./components/MostrarNoticia";


function App() {
  return (
  <Router>
    <div className="container">
      <header className="blog-header py-3">
        <div className="row flex-nowrap justify-content-between align-items-center">
          <div className="col-4 pt-1">
            <a className="text-muted" href="https://getbootstrap.com/docs/4.2/examples/blog/#"></a>
          </div>
          <div className="col-4 text-center">
            <h1>KAR+News</h1>
          </div>
          <div className="col-4 d-flex justify-content-end align-items-center">
            <Link to="/loginA" className="btn btn-sm btn-outline-secondary">Administración</Link> 
          </div>
        </div>
      </header>


      <div className="nav-scroller py-1 mb-2">
        <nav className="nav d-flex justify-content-around ">
          <Link to="/videojuegos" className="p-2 text-muted">Videojuegos</Link>
          <Link to="/cine" className="p-2 text-muted">Cine</Link>
          <Link to="/deportes" className="p-2 text-muted">Deportes</Link>
        </nav>
      </div>
    </div>

    
    <Route path="/"  exact component={Videojuegos}/>
    <Route path="/videojuegos" component={Videojuegos}/>
    <Route path="/cine" component={Cine}/>
    <Route path="/deportes" component={Deportes}/>
    <Route path="/loginA" component={LoginAutores} />
    <Route path="/create" component={CrearNoticia} />
    <Route path="/show/:id" component={MostrarNoticia} />
    <Route path="/edit/:id" component={EditNoticia} />
  </Router>
  );
}

export default App;
