import * as firebase from 'firebase';
import firestore from 'firebase/firestore';

const settings = {timestampsInSnapshots: true};

var firebaseConfig = {
    apiKey: "AIzaSyDL-GeGOllqf9FHxFhGN9o2033FfDwY8Tg",
    authDomain: "pw2db-73aa6.firebaseapp.com",
    databaseURL: "https://pw2db-73aa6.firebaseio.com",
    projectId: "pw2db-73aa6",
    storageBucket: "pw2db-73aa6.appspot.com",
    messagingSenderId: "781865653670",
    appId: "1:781865653670:web:62325d7c6f480dc5"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
//firebase.firestore().settings(settings);


export default firebase;
